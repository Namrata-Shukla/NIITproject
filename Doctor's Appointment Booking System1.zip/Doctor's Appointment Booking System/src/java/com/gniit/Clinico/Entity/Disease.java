/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Entity;

/**
 *
 * @author Namrata
 */
public class Disease {
    int Disease_ID;
    String Disease_Name;
    
    String Disease_Symptoms;
    String Disease_Remedies;
    int Doctor_ID;

    public int getDisease_ID() {
        return Disease_ID;
    }

    public void setDisease_ID(int Disease_ID) {
        this.Disease_ID = Disease_ID;
    }

    public String getDisease_Name() {
        return Disease_Name;
    }

    public void setDisease_Name(String Disease_Name) {
        this.Disease_Name = Disease_Name;
    }

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public String getDisease_Symptoms() {
        return Disease_Symptoms;
    }

    public void setDisease_Symptoms(String Disease_Symptoms) {
        this.Disease_Symptoms = Disease_Symptoms;
    }

    public String getDisease_Remedies() {
        return Disease_Remedies;
    }

    public void setDisease_Remedies(String Disease_Remedies) {
        this.Disease_Remedies = Disease_Remedies;
    }
    public Disease(){}

    public Disease(int id, String name, String sym, String rem, int did) {
        this.Disease_ID = id;
        this.Disease_Name = name;
        this.Disease_Symptoms = sym;
        this.Disease_Remedies = rem;
    this.Doctor_ID = did;
    
    }
public Disease(String name, String sym, String rem, int did) {
    
        this.Disease_Name = name;
        this.Disease_Symptoms = sym;
        this.Disease_Remedies = rem;
    this.Doctor_ID = did;
    
    }
   
}
