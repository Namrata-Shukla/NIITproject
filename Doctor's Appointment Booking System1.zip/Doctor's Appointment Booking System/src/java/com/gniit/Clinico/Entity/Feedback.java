/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Entity;

/**
 *
 * @author Namrata
 */
public class Feedback {
    int Feedback_ID;
    String Feedback_Details;

    public int getFeedback_ID() {
        return Feedback_ID;
    }

    public void setFeedback_ID(int Feedback_ID) {
        this.Feedback_ID = Feedback_ID;
    }

    public String getFeedback_Details() {
        return Feedback_Details;
    }

    public void setFeedback_Details(String Feedback_Details) {
        this.Feedback_Details = Feedback_Details;
    }
public Feedback(){}

    public Feedback(int id, String details) {
        this.Feedback_ID = id;
        this.Feedback_Details = details;
         
   
    }

    public Feedback(String details) {
        this.Feedback_Details = details;
     
      
    }
}
