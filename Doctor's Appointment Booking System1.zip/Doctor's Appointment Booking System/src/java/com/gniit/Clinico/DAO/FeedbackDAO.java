/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.FeedbackDAO;

import com.gniit.Clinico.Entity.Feedback;
import java.util.List;

/**
 *
 * @author Namrata
 */
public interface FeedbackDAO {
    int addfeedback(Feedback feedback);
    int deleteFeedback(int Feedback_ID);
    List <Feedback> getFeedbacks();
    Feedback getFeedbackByID(int Feedback_ID);
    int updateFeedback(int Feedback_ID,Feedback feedback);
}
