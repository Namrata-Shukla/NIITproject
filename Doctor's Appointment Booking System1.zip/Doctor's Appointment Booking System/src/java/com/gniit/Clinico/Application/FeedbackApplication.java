/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Application;

import com.gniit.Clinico.DAOimpl.FeedbackDAOImpl;
import com.gniit.Clinico.Entity.Feedback;
import java.util.List;
import com.gniit.Clinico.FeedbackDAO.FeedbackDAO;

/**
 *
 * @author Namrata
 */
public class FeedbackApplication {
     public static void main(String[] args){
        FeedbackDAO feedbackDAO = new FeedbackDAOImpl();
              int count = feedbackDAO.addfeedback(new Feedback(3,"can do better"));
        if(count>0)System.out.println("Record Added Successfully");
        else System.out.println("Record Failed to get added");
// count=feedbackDAO.deleteFeedback(1);
  //      if(count>0)System.out.println("Record Deleted Successfully");
    //    else System.out.println("Record Failed to get deleted");
       //  Feedback feedback = new Feedback(2,"excellent");
     //count=feedbackDAO.updateFeedback(2, feedback);
       // if(count>0)System.out.println("Record Updated Successfully");
        //else System.out.println("Record Failed to get updated");
         List<Feedback> feedbacklist = feedbackDAO.getFeedbacks();
        for(Feedback emp : feedbacklist){
            System.out.println(emp.getFeedback_ID() + "|" + emp.getFeedback_Details());
        }
      Feedback feed = feedbackDAO.getFeedbackByID(3);
            System.out.println(feed.getFeedback_ID()+ "|" + feed.getFeedback_Details());
    }
}



