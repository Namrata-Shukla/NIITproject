/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Application;

import com.gniit.Clinico.DAOimpl.PatientDAOImpl;

import com.gniit.Clinico.Entity.Patient;
import java.util.List;
import com.gniit.Clinico.DAO.PatientDAO;
import java.util.Scanner;

/**
 *
 * @author Namrata
 */
public class PatientApplication {
        public static void main(String[] args){
        PatientDAO patientDAO = new PatientDAOImpl();
              int count = patientDAO.addPatient(new Patient("Stany","fgb","s@.g",8353965,"1/1/5236"));
        if(count>0)System.out.println("Record Added Successfully");
        else System.out.println("Record Failed to get added");
        
        List<Patient> patientList = patientDAO.getPatients();
        System.out.println("No of records " + patientList.size());
        
  //      count=patientDAO.deletePatient(2);
    //if(count>0)System.out.println("Record Deleted Successfully");
      //else System.out.println("Record Failed to get deleted");
       // Patient pat = new Patient(3,"Kat","Perry","WDD",564,"12/21/5446");
     //count=patientDAO.updatePatient(3, pat);
       //if(count>0)System.out.println("Record Updated Successfully");
        //else System.out.println("Record Failed to get updated");
      // List<Patient> patientlist = patientDAO.getPatients();
        //for(Patient emp : patientlist){
          //  System.out.println(emp.getPatient_ID()+ "|" + emp.getName()+ "|" + emp.getAddress()+ "|" + emp.getEmail_ID() + "|" + emp.getjoindate() + "|" + emp.getContact_No());
       //}
  //  Patient petty= patientDAO.getPatientByID(3);
    //       System.out.println(petty.getName()+ "|" + petty.getAddress()+ "|" + petty.getEmail_ID() + "|" + petty.getjoindate() + "|" + petty.getContact_No());
        
}

}

