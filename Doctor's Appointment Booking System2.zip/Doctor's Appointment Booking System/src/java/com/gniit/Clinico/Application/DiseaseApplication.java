/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Application;

import com.gniit.Clinico.DAOimpl.DiseaseDAOImpl;
import com.gniit.Clinico.Entity.Disease;
import java.util.List;
import com.gniit.Clinico.DAO.DiseaseDAO;

/**
 *
 * @author Namrata
 */
public class DiseaseApplication {
     public static void main(String[] args){
        DiseaseDAO diseaseDAO = new DiseaseDAOImpl();
            //  int count = diseaseDAO.adddisease(new Disease(4,"Kartiki","Dave","sas",145));
        //if(count>0)System.out.println("Record Added Successfully");
        //else System.out.println("Record Failed to get added");
//count=diseaseDAO.deleteDisease(2);
  //    if(count>0)System.out.println("Record Deleted Successfully");
    //  else System.out.println("Record Failed to get deleted");
      //  Disease dis = new Disease(3,"Aisha","Takiya","fgh",140);
     //count=diseaseDAO.updateDisease(3, dis);
       //if(count>0)System.out.println("Record Updated Successfully");
        //else System.out.println("Record Failed to get updated");
       //  List<Disease> diseaselist = diseaseDAO.getDiseases();
        //for(Disease emp : diseaselist){
          //  System.out.println(emp.getDisease_ID()+ "|" + emp.getDisease_Name()+ "|" + emp.getDisease_Remedies()+ "|" + emp.getDisease_Symptoms() + "|" + emp.getDoctor_ID());
       //}
     Disease diss= diseaseDAO.getDiseaseByID(3);
           System.out.println(diss.getDisease_Name()+ "|" + diss.getDisease_Remedies()+ "|" + diss.getDisease_Symptoms() + "|" + diss.getDoctor_ID());

        
}
     
}
