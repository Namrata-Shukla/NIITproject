/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Application;

import com.gniit.Clinico.DAOimpl.AppointmentDaOImpl;
import com.gniit.Clinico.Entity.Appointment;
import java.util.List;
import com.gniit.Clinico.DAO.AppointmentDAO;

/**
 *
 * @author Namrata
 */
public class AppointmentApplication {
     public static void main(String[] args){
        AppointmentDAO aptDAO = new AppointmentDaOImpl();
            int count = aptDAO.addappointment(new Appointment(1002,3232,4312,1702));
        if(count>0)System.out.println("Record Added Successfully");
        else System.out.println("Record Failed to get added");
 count=aptDAO.deleteAppointment(1001);
      if(count>0)System.out.println("Record Deleted Successfully");
       else System.out.println("Record Failed to get deleted");
        Appointment appointment = new Appointment(1002,3233,4313,1703);
     count=aptDAO.updateAppointment(1002, appointment);
        if(count>0)System.out.println("Record Updated Successfully");
        else System.out.println("Record Failed to get updated");
         //List<Appointment> appointmentlist = aptDAO.getAppointments();
        //for(Appointment emp : appointmentlist){
          //  System.out.println(emp.getAppointment_id() + "|" + emp.getPatient_ID() + "|" + emp.getDoctor_ID() + "|" + emp.getTiming_Slot());
      //  }
    //  Appointment app= aptDAO.getAppointmentByID(1001);
      //      System.out.println(app.getAppointment_id()+ "|" + app.getPatient_ID() + "|" + app.getDoctor_ID() + "|" + app.getTiming_Slot());

}
}
