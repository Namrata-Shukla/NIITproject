/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAOimpl;

import DB_Connection.DBconnection;
import com.gniit.Clinico.Entity.Appointment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.gniit.Clinico.DAO.AppointmentDAO;

/**
 *
 * @author Namrata
 */
public class AppointmentDaOImpl implements AppointmentDAO {

    @Override
    public int addappointment(Appointment appointment) {
     Connection con=DBconnection.getConnection();
    
  
        int count=0;
       
        try {
             String query="insert into Appointment(AppointmentId,PatientId,DoctorId,TimingSlot) values(?,?,?,?)";
             
      PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,appointment.getAppointment_id());
            pst.setInt(2,appointment.getPatient_ID());
            pst.setInt(3,appointment.getDoctor_ID());
              pst.setInt(4,appointment.getTiming_Slot());
         
                
            count = pst.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentDaOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
 
        return count;
    
    }

    @Override
    public int deleteAppointment(int Appointment_ID) {
       int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Appointment where AppointmentId=?");
            preparedStatement.setInt(1,Appointment_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentDaOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
        
        
        
    

    }

    @Override
    public List<Appointment> getAppointments() {
         List<Appointment> appointmentList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Appointment");
            ResultSet rs = preparedStatement.executeQuery();
            appointmentList = new ArrayList<Appointment>();
            if(rs!=null){
               
                while(rs.next()){
                    int aid = rs.getInt(1);
                    int pid = rs.getInt(2);
                    int did = rs.getInt(3);
                    int timingslot = rs.getInt(4);
                 
                  
                    Appointment appointment = new Appointment(aid,pid,did,timingslot);
                    appointmentList.add(appointment);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentDaOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return appointmentList;

       
    }

    @Override
    public Appointment getAppointmentByID(int Appointment_ID) {
       List<Appointment> appointmentList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Appointment where AppointmentId=?");
        
            preparedStatement.setInt(1,Appointment_ID);
            ResultSet rs = preparedStatement.executeQuery();
           appointmentList = new ArrayList<Appointment>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    int pid = rs.getInt(2);
                    int did = rs.getInt(3);
                    
                    int timingslot = rs.getInt(4);
                
                    Appointment appointment = new Appointment(id,pid,did,timingslot);
                   appointmentList.add(appointment);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentDaOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(appointmentList.size()>0) return appointmentList.get(0);
     else return null;
       
    }

    @Override
    public int updateAppointment(int Appointment_ID, Appointment appointment) {
      int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Appointment set PatientId=?, DoctorId=?, TimingSlot=? where AppointmentId=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,appointment.getAppointment_id());
            pst.setInt(2,appointment.getPatient_ID());
            pst.setInt(3,appointment.getDoctor_ID());
              pst.setInt(4,appointment.getTiming_Slot());
                
                  count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentDaOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
 
    }
    

