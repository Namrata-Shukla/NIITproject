/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAOimpl;

import DB_Connection.DBconnection;
import com.gniit.Clinico.Entity.Feedback;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import java.util.ArrayList;
import com.gniit.Clinico.FeedbackDAO.FeedbackDAO;

/**
 *
 * @author Namrata
 */
public class FeedbackDAOImpl implements FeedbackDAO {
Connection con=DBconnection.getConnection();
    @Override
    public int addfeedback(Feedback feedback) {
       int count=0;
       
        try {
             String query="insert into Feedback(FeedbackId,Name,FeedbackDetails) values(?,?,?)";
             
      PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,feedback.getFeedback_ID());
            pst.setString(2,feedback.getFeedback_Name());
             pst.setString(3,feedback.getFeedback_Details());
           
            count = pst.executeUpdate();
           
        } catch(SQLException ex) {
            Logger.getLogger(FeedbackDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
      return count;
    
    }

    @Override
    public int deleteFeedback(int Feedback_ID) {
        int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Feedback where FeedbackId=?");
            preparedStatement.setInt(1,Feedback_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
        
        
    }

    @Override
    public List<Feedback> getFeedbacks() {
         List<Feedback> feedbackList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Feedback");
            ResultSet rs = preparedStatement.executeQuery();
            feedbackList = new ArrayList<Feedback>();
            if(rs!=null){
               
                while(rs.next()){
                    int id = rs.getInt(1);
                    String Name=rs.getString(2);
                    String details = rs.getString(3);
                     Feedback feedback = new Feedback(id,Name,details);
                  feedbackList.add(feedback);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return feedbackList;

        
        
    }

    @Override
    public Feedback getFeedbackByID(int Feedback_ID) {
        List<Feedback> feedbackList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Feedback where FeedbackId=?");
            preparedStatement.setInt(1, Feedback_ID);
            ResultSet rs = preparedStatement.executeQuery();
          feedbackList = new ArrayList<Feedback>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    String Name=rs.getString(2);
                    String details = rs.getString(3);
                    
                    Feedback feedback = new Feedback(id,Name,details);
                   feedbackList.add(feedback);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(feedbackList.size()>0) return feedbackList.get(0);
     else return null;
        
    }

    @Override
    public int updateFeedback(int Feedback_ID, Feedback feedback) {
          int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Feedback set Name=? details=? where FeedbackId=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,feedback.getFeedback_ID());
            pst.setString(2,feedback.getFeedback_Name());
             pst.setString(3,feedback.getFeedback_Details());
                 count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(FeedbackDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    
        
    }
    
}
